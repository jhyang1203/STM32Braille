/*
 * delay.h
 *
 *  Created on: Jun 27, 2025
 *      Author: kccistc
 */

#ifndef AP_INC_DELAY_H_
#define AP_INC_DELAY_H_

#include "tim.h"
#include "stm32f4xx_hal.h"

void delay_01ms(uint32_t time);


#endif /* AP_INC_DELAY_H_ */
