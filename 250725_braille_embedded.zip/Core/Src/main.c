/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include "dma.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "nrf24l01p.h"
#include "Listener.h"
#include "ili9341.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// #define RECEIVER  // 수신이면 이걸 주석 해제

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void MX_FREERTOS_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{

	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */
	ILI9341_Init();
	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_USART2_UART_Init();
	MX_TIM3_Init();
	MX_TIM5_Init();
	MX_TIM2_Init();
	MX_SPI2_Init();
	MX_USART1_UART_Init();
	MX_TIM4_Init();
	MX_SPI3_Init();
	MX_USART6_UART_Init();
	/* USER CODE BEGIN 2 */
	//nrf24l01p_rx_init(2500, _1Mbps);
	//	#ifdef RECEIVER
	nrf24l01p_rx_init(2500, _1Mbps);
	//	#endif
	//
	//	#ifdef TRANSMITTER
	//	  nrf24l01p_tx_init(2500, _1Mbps);
	//	#endif

	/* USER CODE END 2 */

	/* Call init function for freertos objects (in cmsis_os2.c) */
	MX_FREERTOS_Init();

	/* Start scheduler */
	osKernelStart();

	/* We should never get here as control is now taken by the scheduler */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = {0};
	RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

	/** Configure the main internal regulator output voltage
	 */
	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLM = 4;
	RCC_OscInitStruct.PLL.PLLN = 100;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
	RCC_OscInitStruct.PLL.PLLQ = 4;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
			|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
	{
		Error_Handler();
	}
}

/* USER CODE BEGIN 4 */
//void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
//{
//	uint8_t rx_buf[NRF24L01P_PAYLOAD_LENGTH];
//	char msg[64];
//
//	if (GPIO_Pin == NRF24L01P_IRQ_PIN_NUMBER)
//	{
//		if (rf_state == S_RX_MODE){
//			nrf24l01p_read_rx_fifo_dma(); 	// NRF 모듈에서 수신된 데이터 읽기
//			nrf24l01p_rx_receive(rx_buf);
//
//			// 수신 내용 UART 디버깅 출력
//			snprintf(msg, sizeof(msg), "RX: 0x%02X \r\n", rx_buf[0]);
//			HAL_UART_Transmit(&huart2, (uint8_t *)msg, strlen(msg), 1000);
//		}
//
//		if (rf_state == S_TX_MODE){
//			nrf24l01p_tx_irq();               // 송신 완료 처리
//		}
//	}
//}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	uint8_t rx_buf[NRF24L01P_PAYLOAD_LENGTH];
	char msg[64];

	if (GPIO_Pin == NRF24L01P_IRQ_PIN_NUMBER)
	{
		if (rf_state == S_RX_MODE){
			nrf24l01p_read_rx_fifo_dma(); 	// NRF 모듈에서 수신된 데이터 읽기
		}

		if (rf_state == S_TX_MODE){
			nrf24l01p_tx_irq();               // 송신 완료 처리
		}
	}
}

void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
	if (hspi->Instance == SPI2 && rf_state == S_RX_MODE)
	{
		cs_high();  // ✅ 통신 종료
		// HAL_UART_Transmit(&huart2, (uint8_t *)"---Rx start(interrupt)---\r\n", strlen("---Rx start(interrupt)---\r\n"), 1000);
		uint8_t status = spi_rx_buf[0]; 	        // STATUS 레지스터 확인 (선택사항)
		uint8_t* Rx_Data = &spi_rx_buf[1];	        // 실제 수신 데이터 (32바이트)

		nrf24l01p_clear_rx_dr();	        		// status 플래그 클리어

		osMessagePut(RFRx_brailleMsgBox, Rx_Data[0], 0); // 메시지 큐로 데이터 전송

		char msg[64];
		snprintf(msg, sizeof(msg), "RX: 0x%02X \r\n", Rx_Data[0]);
		HAL_UART_Transmit(&huart2, (uint8_t *)msg, strlen(msg), 1000);


		//		char msg[64];
		//		snprintf(msg, sizeof(msg), "RX: 0x%02X\r\n", Rx_Data[0]);
		//		HAL_UART_Transmit(&huart2, (uint8_t *)msg, strlen(msg), 1000);

		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);	        // 디버깅용 LED 토글
	}
}

//void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
//{
//	if (hspi->Instance == SPI2 && rf_state == S_RX_MODE)
//	{
//		cs_high();  // ✅ 통신 종료
//		HAL_UART_Transmit(&huart2, (uint8_t *)"---Rx start(interrupt)---\r\n", strlen("---Rx start(interrupt)---\r\n"), 1000);
//		uint8_t status = spi_rx_buf[0]; 	        // STATUS 레지스터 확인 (선택사항)
//		uint8_t* Rx_Data = &spi_rx_buf[1];	        // 실제 수신 데이터 (32바이트)
//
//		nrf24l01p_clear_rx_dr();	        		// status 플래그 클리어
//
//		osMessagePut(RFRx_brailleMsgBox, Rx_Data[0], 0); // 메시지 큐로 데이터 전송
//
//		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);	        // 디버깅용 LED 토글
//	}
//}


/* USER CODE END 4 */

/**
 * @brief  Period elapsed callback in non blocking mode
 * @note   This function is called  when TIM11 interrupt took place, inside
 * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
 * a global variable "uwTick" used as application time base.
 * @param  htim : TIM handle
 * @retval None
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	/* USER CODE BEGIN Callback 0 */

	/* USER CODE END Callback 0 */
	if (htim->Instance == TIM11)
	{
		HAL_IncTick();
	}
	/* USER CODE BEGIN Callback 1 */
	if (htim->Instance == TIM4)
	{
		//		HAL_UART_Transmit(&huart2, (uint8_t *)"---Tx finish(interrupt)---\r\n", strlen("---Tx finish(interrupt)---\r\n"), 1000);
		tx_done_flag = 1;
	}
	/* USER CODE END Callback 1 */
}

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1)
	{
	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
	/* USER CODE BEGIN 6 */
	/* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
	/* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
