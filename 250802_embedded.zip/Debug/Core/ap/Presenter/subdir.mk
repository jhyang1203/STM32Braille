################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/ap/Presenter/Presenter.c \
../Core/ap/Presenter/Presenter_DFPMini.c \
../Core/ap/Presenter/Presenter_LCD.c \
../Core/ap/Presenter/Presenter_Motor.c \
../Core/ap/Presenter/Presenter_RF_Transfer.c 

OBJS += \
./Core/ap/Presenter/Presenter.o \
./Core/ap/Presenter/Presenter_DFPMini.o \
./Core/ap/Presenter/Presenter_LCD.o \
./Core/ap/Presenter/Presenter_Motor.o \
./Core/ap/Presenter/Presenter_RF_Transfer.o 

C_DEPS += \
./Core/ap/Presenter/Presenter.d \
./Core/ap/Presenter/Presenter_DFPMini.d \
./Core/ap/Presenter/Presenter_LCD.d \
./Core/ap/Presenter/Presenter_Motor.d \
./Core/ap/Presenter/Presenter_RF_Transfer.d 


# Each subdirectory must supply rules for building sources it contributes
Core/ap/Presenter/%.o Core/ap/Presenter/%.su Core/ap/Presenter/%.cyclo: ../Core/ap/Presenter/%.c Core/ap/Presenter/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/Button" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/LCD" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Model" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Controller" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Listener" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Presenter" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/Motor" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/RF" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/DFplayerMini" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/ButtonPushLock" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-ap-2f-Presenter

clean-Core-2f-ap-2f-Presenter:
	-$(RM) ./Core/ap/Presenter/Presenter.cyclo ./Core/ap/Presenter/Presenter.d ./Core/ap/Presenter/Presenter.o ./Core/ap/Presenter/Presenter.su ./Core/ap/Presenter/Presenter_DFPMini.cyclo ./Core/ap/Presenter/Presenter_DFPMini.d ./Core/ap/Presenter/Presenter_DFPMini.o ./Core/ap/Presenter/Presenter_DFPMini.su ./Core/ap/Presenter/Presenter_LCD.cyclo ./Core/ap/Presenter/Presenter_LCD.d ./Core/ap/Presenter/Presenter_LCD.o ./Core/ap/Presenter/Presenter_LCD.su ./Core/ap/Presenter/Presenter_Motor.cyclo ./Core/ap/Presenter/Presenter_Motor.d ./Core/ap/Presenter/Presenter_Motor.o ./Core/ap/Presenter/Presenter_Motor.su ./Core/ap/Presenter/Presenter_RF_Transfer.cyclo ./Core/ap/Presenter/Presenter_RF_Transfer.d ./Core/ap/Presenter/Presenter_RF_Transfer.o ./Core/ap/Presenter/Presenter_RF_Transfer.su

.PHONY: clean-Core-2f-ap-2f-Presenter

