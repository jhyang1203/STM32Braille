################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/ap/Controller/Controller.c \
../Core/ap/Controller/Controller_CNN.c \
../Core/ap/Controller/Switch.c 

OBJS += \
./Core/ap/Controller/Controller.o \
./Core/ap/Controller/Controller_CNN.o \
./Core/ap/Controller/Switch.o 

C_DEPS += \
./Core/ap/Controller/Controller.d \
./Core/ap/Controller/Controller_CNN.d \
./Core/ap/Controller/Switch.d 


# Each subdirectory must supply rules for building sources it contributes
Core/ap/Controller/%.o Core/ap/Controller/%.su Core/ap/Controller/%.cyclo: ../Core/ap/Controller/%.c Core/ap/Controller/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/Button" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/LCD" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Model" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Controller" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Listener" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Presenter" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/Motor" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/RF" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/DFplayerMini" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/ButtonPushLock" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-ap-2f-Controller

clean-Core-2f-ap-2f-Controller:
	-$(RM) ./Core/ap/Controller/Controller.cyclo ./Core/ap/Controller/Controller.d ./Core/ap/Controller/Controller.o ./Core/ap/Controller/Controller.su ./Core/ap/Controller/Controller_CNN.cyclo ./Core/ap/Controller/Controller_CNN.d ./Core/ap/Controller/Controller_CNN.o ./Core/ap/Controller/Controller_CNN.su ./Core/ap/Controller/Switch.cyclo ./Core/ap/Controller/Switch.d ./Core/ap/Controller/Switch.o ./Core/ap/Controller/Switch.su

.PHONY: clean-Core-2f-ap-2f-Controller

