Core/ap/Model/BrailleTable.o: ../Core/ap/Model/BrailleTable.c \
 ../Core/ap/Model/BrailleTable.h
../Core/ap/Model/BrailleTable.h:
