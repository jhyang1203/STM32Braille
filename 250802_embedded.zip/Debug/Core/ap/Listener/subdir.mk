################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/ap/Listener/Listener.c \
../Core/ap/Listener/Listener_CNN.c \
../Core/ap/Listener/Listener_Switch.c 

OBJS += \
./Core/ap/Listener/Listener.o \
./Core/ap/Listener/Listener_CNN.o \
./Core/ap/Listener/Listener_Switch.o 

C_DEPS += \
./Core/ap/Listener/Listener.d \
./Core/ap/Listener/Listener_CNN.d \
./Core/ap/Listener/Listener_Switch.d 


# Each subdirectory must supply rules for building sources it contributes
Core/ap/Listener/%.o Core/ap/Listener/%.su Core/ap/Listener/%.cyclo: ../Core/ap/Listener/%.c Core/ap/Listener/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/Button" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/LCD" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Model" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Controller" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Listener" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Presenter" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/Motor" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/RF" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/DFplayerMini" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/ButtonPushLock" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-ap-2f-Listener

clean-Core-2f-ap-2f-Listener:
	-$(RM) ./Core/ap/Listener/Listener.cyclo ./Core/ap/Listener/Listener.d ./Core/ap/Listener/Listener.o ./Core/ap/Listener/Listener.su ./Core/ap/Listener/Listener_CNN.cyclo ./Core/ap/Listener/Listener_CNN.d ./Core/ap/Listener/Listener_CNN.o ./Core/ap/Listener/Listener_CNN.su ./Core/ap/Listener/Listener_Switch.cyclo ./Core/ap/Listener/Listener_Switch.d ./Core/ap/Listener/Listener_Switch.o ./Core/ap/Listener/Listener_Switch.su

.PHONY: clean-Core-2f-ap-2f-Listener

