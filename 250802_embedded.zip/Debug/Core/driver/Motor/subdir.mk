################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/driver/Motor/Motor.c 

OBJS += \
./Core/driver/Motor/Motor.o 

C_DEPS += \
./Core/driver/Motor/Motor.d 


# Each subdirectory must supply rules for building sources it contributes
Core/driver/Motor/%.o Core/driver/Motor/%.su Core/driver/Motor/%.cyclo: ../Core/driver/Motor/%.c Core/driver/Motor/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F411xE -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/Button" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/LCD" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Model" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Controller" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Listener" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap/Presenter" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/Motor" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/RF" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/DFplayerMini" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver/ButtonPushLock" -I"D:/working/Harman_1_STM32/250802_embedded/Core/ap" -I"D:/working/Harman_1_STM32/250802_embedded/Core/driver" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-driver-2f-Motor

clean-Core-2f-driver-2f-Motor:
	-$(RM) ./Core/driver/Motor/Motor.cyclo ./Core/driver/Motor/Motor.d ./Core/driver/Motor/Motor.o ./Core/driver/Motor/Motor.su

.PHONY: clean-Core-2f-driver-2f-Motor

