Core/driver/LCD/fonts.o: ../Core/driver/LCD/fonts.c \
 ../Core/driver/LCD/fonts.h
../Core/driver/LCD/fonts.h:
